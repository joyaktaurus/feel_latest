// @dart=2.9


class CountryData {
  int id;
  String cname;
  String country_photo;
  // String currency_name;

  CountryData(
      {this.id,
        this.cname,
        this.country_photo,
        // this.currency_name
      });


}

