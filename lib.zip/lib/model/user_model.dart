// @dart=2.9
class UserModel {
  User user;
  String message;

  UserModel({this.user, this.message});

  UserModel.fromJson(Map<String, dynamic> json) {
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.user != null) {
      data['user'] = this.user.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class User {
  String name;
  String phoneNumber;
  var hideStatus;
  String token;
  String updatedAt;
  String createdAt;
  int id;
  String customerAddress;

  User(
      {this.name,
      this.phoneNumber,
      this.hideStatus,
      this.token,
      this.updatedAt,
      this.createdAt,
      this.id,
      this.customerAddress});

  User.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    phoneNumber = json['phone_number'];
    hideStatus = json['hide_status'];
    token = json['token'];
    updatedAt = json['updated_at'];
    createdAt = json['created_at'];
    id = json['id'];
    customerAddress = json['customer_address'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['phone_number'] = this.phoneNumber;
    data['hide_status'] = this.hideStatus;
    data['token'] = this.token;
    data['updated_at'] = this.updatedAt;
    data['created_at'] = this.createdAt;
    data['id'] = this.id;
    data['customer_address'] = this.customerAddress;
    return data;
  }
}
