// @dart=2.9
import 'package:feelathomeproject/util/menu_line.dart';
import 'package:flutter/material.dart';
import 'login.dart';


class Tab_profile extends StatefulWidget {
  //const SplashScreen() : super(key: key);

  @override
  _Tab_profileState createState() => _Tab_profileState();
}

class _Tab_profileState extends State<Tab_profile> {

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 40.0, left: 10.0),
              child: Container(
                  child: Text(
                    'My profile',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 34.0),
                  )),
            ),
            SizedBox(
              height: 5.0,
            ),
            ListTile(
              leading: Container(
                height: 60.0,
                width: 60.0,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage('assets/profile/user-profile.jpeg'))),
              ),
              title: Text(
                //TODO: take from profile info
                'Matilda Brown',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                //TODO: take from profile info
                'matildabrown@mail.com',
                style: TextStyle(
                    color: Colors.grey, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 25.0,
            ),
            OpenFlutterMenuLine(
                title: 'My orders',
                //TODO: make short card info
                subtitle: 'Already Have 12 orders',),
            Divider(),
            OpenFlutterMenuLine(
                title: 'Shipping addresses',
                //TODO: make dynamic address count
                subtitle: '3 addresses',
                onTap: (() => {

                })),
            Divider(),
            OpenFlutterMenuLine(
                title: 'Payments methods',
                //TODO: make short card info
                subtitle: 'visa **34',
                onTap: (() => {

                })),
            Divider(),
            OpenFlutterMenuLine(
                title: 'Promocodes',
                //TODO: make dynamic later
                subtitle: 'You have special promocodes',
                onTap: (() => {

                })),
            Divider(),
            OpenFlutterMenuLine(
                title: 'My reviews',
                //TODO: make dynamic later
                subtitle: 'review for 4 items',
                onTap: (() => {

                })),
            Divider(),
            OpenFlutterMenuLine(
                title: 'Settings',
                subtitle: 'Notification, Password',
                onTap: (() => {

                  //Navigator.of(context).pushNamed(OpenFlutterEcommerceRoutes.settings)
                })),
            Divider(),
            OpenFlutterMenuLine(
                title: 'SignIn/SignUp',
                subtitle: 'Connect your web account',
                onTap: (() => {
                }))
          ],
        )
      ],
    );
  }
  }
