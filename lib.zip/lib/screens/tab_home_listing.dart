import 'package:flutter/material.dart';
import 'login.dart';


class Tab_home_listing extends StatefulWidget {
  //const SplashScreen() : super(key: key);

  @override
  _Tab_home_listingState createState() => _Tab_home_listingState();
}

class _Tab_home_listingState extends State<Tab_home_listing> {


  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF33cdde),Color(0xFF028b9b)])),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Container(
                          child: Image.asset(
                            "assets/images/logo.png",
                            height: 150.0,
                            width: 150.0,
                            fit: BoxFit.fill,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              left: 0.0, right: 0.0, top: 10.0),
                          child: const Text(
                            'Fh',
                            style: TextStyle(fontFamily: 'kistalbld',color: Colors.white,fontSize: 20),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 1.0),
                          child: const Text(
                            "Guardian far from home",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'kistalitl',
                              color: Colors.white,
                              fontWeight: FontWeight.normal,
                              fontSize: 19.0,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        // decoration: BoxDecoration(
        //     image: DecorationImage(
        //   fit: BoxFit.fill,
        //   image: AssetImage(
        //     "assets/images/logo_new.jpeg",
        //   ),
        // )),
      ),
    );
  }
}
// child: Container(
// width: MediaQuery.of(context).size.width,
// height: MediaQuery.of(context).size.width,
// child: Column(
// children: [
// Container(
// width: 300,
// height: 300,
// decoration: BoxDecoration(
// image: DecorationImage(image: AssetImage('assets/images/logo.jpg'))
// ),
// ),
// Text(' Connect One Video Shopping', textAlign: TextAlign.center, style: TextStyle(
// color: Color.fromRGBO(0, 0, 0, 1),
// fontFamily: 'Ubuntu',
// fontSize: 24,
// letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
// fontWeight: FontWeight.normal,
// height: 1
// ),)
// ],
// ),
// ),
