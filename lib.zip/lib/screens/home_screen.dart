// @dart=2.9
import 'package:feelathomeproject/screens/tab_home_listing.dart';
import 'package:feelathomeproject/screens/tab_profile.dart';
import 'package:feelathomeproject/screens/tab_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  MethodChannel channel = MethodChannel("samples.flutter.dev/battery");
  var scaffoldKey = GlobalKey<ScaffoldState>();
  int selectedPage = 0;
  final _pageOptions = [Tab_home_listing(), Tab_search(), Tab_profile()];

  @override
  Widget build(BuildContext context) {
   return Scaffold(
      body: _pageOptions[selectedPage],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedPage, //New
        onTap: _onItemTapped,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage("assets/images/home.png")),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage("assets/images/search.png")),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage("assets/images/account.png")),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
  void _onItemTapped(int index) {
    setState(() {
      selectedPage = index;
    });
  }
}
