import 'package:flutter/material.dart';
import '../util/light_color.dart';
import 'package:country_list_pick/country_list_pick.dart';

class Tab_search extends StatefulWidget {
  //const SplashScreen() : super(key: key);

  @override
  _Tab_searchState createState() => _Tab_searchState();
}

class _Tab_searchState extends State<Tab_search> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Colors.green.shade50,
      body: Container(
        child: Column(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left:10,right:10,top:50),
                    width: MediaQuery.of(context).size.width,
                    height: 120,
                    decoration: new BoxDecoration(color: Colors.white),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5.0),
                          child: _search(),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 40.0, top: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/filter.png",
                                      height: 15.0,
                                      width: 20.0,
                                      fit: BoxFit.fill,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 2.0),
                                      child: const Text(
                                        "Filter",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 10.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Container(
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/sort.png",
                                      height: 15.0,
                                      width: 20.0,
                                      fit: BoxFit.fill,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 2.0),
                                      child: const Text(
                                        "Sort",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 10.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    /*  Container(
                        height: MediaQuery.of(context).size.height * .7,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20.0, vertical: 0),
                              child: Container(),
                            ),
                          ],
                        ),
                      );*/
                  ),
                ],
              ),
            ),
            Expanded(
              child:getBody(),
            ),
          ],
        ),

      ),
    );
  }
  Widget getBody(){
    return ListView(
      children: <Widget>[
        Container(
          color: Colors.lime[800],
          //child: const Center(child: Text('Apple')),
          child: ListTile(
            title: Column(
              children: [
                Row(
                  children: <Widget>[
                    Container(
                      width: 100,
                      height: 100,
                      child: Image.asset(
                        "assets/images/logo.png",
                        height: 100.0,
                        width: 100.0,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                              width: MediaQuery.of(context).size.width-140,
                              child: Text("Heading",style: TextStyle(color: Colors.purple[500],
                                  fontSize: 20.5, fontWeight: FontWeight.bold),)),
                          SizedBox(
                              width: MediaQuery.of(context).size.width-140,
                              child: Text("Description",style: TextStyle(color: Colors.grey,),)),
                          SizedBox(height: 30,),
                          Text("Text", style: new TextStyle(color: Colors.purple, fontSize: 15.0, fontWeight: FontWeight.normal)),
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                  ],
                ),
                Container(
                    width: MediaQuery.of(context).size.width-30,
                    height: 1,
                    child:Divider(color: Colors.purple)
                  //drawing horizontal dotted/dash line
                ),
              ],
            ),
            onTap: () {
            },
          ),
        ),
        Container(
          height: 50,
          color: Colors.lime[600],
          child: const Center(child: Text('Banana')),
        ),
        Container(
          height: 50,
          color: Colors.lime[400],
          child: const Center(child: Text('Mango')),
        ),
        Container(
          height: 50,
          color: Colors.lime[200],
          child: const Center(child: Text('Orange')),
        ),
      ],
    );
  }
  Widget _search() {
    return Container(
      margin: EdgeInsets.only(left: 5.0, top: 10.0),
      child: Row(
        children: <Widget>[
          CountryListPick(
            appBar: AppBar(
              backgroundColor:Colors.green.shade50,
              iconTheme: IconThemeData(color: Colors.black),
              title: const Text('Pick your country', style: TextStyle(
                  color: Colors.blue
              )),
            ),
            theme: CountryTheme(
              isShowFlag: true,
              isShowTitle: true,
              isShowCode: false,
              isDownIcon: true,
              alphabetSelectedTextColor:Colors.black,
              alphabetTextColor:Colors.black,
              showEnglishName: false,
              labelColor: Colors.blue,
            ),
            initialSelection: '+1',
            // or
            // initialSelection: 'US'
            onChanged: (code) async {
              // print(code.name);
              // print(code.code);
              // print(code.dialCode);
              // print(code.flagUri);
            },
          ),
          Expanded(
            child: Container(
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: LightColor.lightGrey.withAlpha(100),
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: TextField(
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Search",
                    hintStyle: TextStyle(fontSize: 12),
                    contentPadding:
                    EdgeInsets.only(left: 10, right: 10, bottom: 0, top: 5),
                    prefixIcon: Icon(Icons.search, color: Colors.blue)),
              ),
            ),
          ),
          SizedBox(width: 20),
        ],
      ),
    );
  }
}
