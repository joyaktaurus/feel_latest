// @dart=2.9
import 'package:flutter/material.dart';


class OpenFlutterMenuLine extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const OpenFlutterMenuLine(
      { this.title, this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
              color: Colors.grey, fontWeight: FontWeight.bold),
        ),
        trailing: Icon(Icons.chevron_right),
      ),
      onTap: onTap,
    );
  }
}
