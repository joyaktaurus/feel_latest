import 'package:feelathomeproject/util/styles.dart';
import 'package:flutter/material.dart';


label(String title) => Text(title);

InputDecoration buildInputDecoration(String hintText, IconData icon) {
  return InputDecoration(
    filled: true,
    fillColor: GreenLoh,
    prefixIcon: Icon(icon, color:Colors.blue),
    hintText: hintText,
    contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
    enabledBorder: myinputborder(),
    focusedBorder: myfocusborder(),
    border: OutlineInputBorder( //Outline border type for TextFeild
        borderRadius: BorderRadius.all(Radius.circular(20)),
        borderSide: BorderSide(
          color:Colors.redAccent,
          width: 1,
        )
    ),
  );
}
OutlineInputBorder myinputborder(){ //return type is OutlineInputBorder
  return OutlineInputBorder( //Outline border type for TextFeild
      borderRadius: BorderRadius.all(Radius.circular(50)),
      borderSide: BorderSide(
        color: Colors.white60,
        style:BorderStyle.none,
        width: 1,
      )
  );
}

OutlineInputBorder myfocusborder(){
  return OutlineInputBorder( //Outline border type for TextFeild
      borderRadius: BorderRadius.all(Radius.circular(50)),
      borderSide: BorderSide(
        color: Colors.blue.shade50,
        width: 1,
      )
  );
}