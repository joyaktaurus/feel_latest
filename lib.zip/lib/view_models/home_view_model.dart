import 'dart:convert';


import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'base_view_model.dart';


class HomeViewModel extends BaseViewModel {
  final GeolocatorPlatform _geolocatorPlatform = GeolocatorPlatform.instance;
  //Company
 /* CompanyLocation companyPref;
  List<CompanyData> companyList;
  UserViewModel _userViewModel;
  List<LocationData> locationList;
  List<ShopData> _shopList;
  List<ShopData> shopListFiltered;
  List<Category> categoryList = [];
  List<Node> nodes = [];
  TextEditingController autoCompleteController = TextEditingController();
  double latitude = 11.259427;
  double longitude = 75.870818;
  var createCallResponse;

  String location = "Find Your Location";

  filterShops({String searchKey, Category category}) {
    shopListFiltered = [];
    if (searchKey != null) {
      // autoCompleteController.text = searchKey;
      if (searchKey.isEmpty) {
        shopListFiltered = _shopList;
      } else {
        for (ShopData data in _shopList) {
          if (data.name.toLowerCase().contains(searchKey.toLowerCase()) ||
              data.userDetails.category.name
                  .toLowerCase()
                  .contains(searchKey)) {
            shopListFiltered.add(data);
          }
        }
      }
    } else if (category != null) {
      autoCompleteController.text = category.name;
      for (ShopData data in _shopList) {
        if (data.userDetails.category.id == category.id) {
          shopListFiltered.add(data);
        }
      }
    }
    notifyListeners();
  }

  Future<bool> updateCall(var callStatus) async {
    setLoading();
    var callLogId = createCallResponse['data']['id'];
    try {
      var body = {"call_status": callStatus, "call_flag": "0"};
      var data =
          await apiClient.put("${EndPoints.updateCall}$callLogId?", body: body);
      print("RESPONSEEEEE==$data");
      print("CALL UPDATED");
      setSuccess();
      return true;
    } on NetworkException catch (e) {
      onException(e);
      return false;
    }
  }

  Future<bool> createCall(int shopId, String roomId) async {
    var userModel = await sharedPreferenceHelper.getUser();
    var customerId = userModel.user.id;
    setLoading();
    var datetime = DateTime.now().toString();
    try {
      var body = {
        "room_id": roomId,
        "call_date_time": datetime,
        "call_to": shopId,
        //"customer_response_flag": "attend",
        "call_from": customerId,
        "call_type": "customer",
      };

      createCallResponse =
          await apiClient.post("${EndPoints.createCall}", body: body);
      setSuccess();
      return true;
    } on NetworkException catch (e) {
      onException(e);
      return false;
    }
  }



  /*Future<bool> registerToken(UserViewModel userViewModel) async {
    setLoading();
    await userViewModel.getProfile();
    var userModel = userViewModel.userModel;
    var fcmToken = await FirebaseMessaging.instance.getToken();

    try {
      var body = {
        "user_id": userModel.user.id,
        "call_type": "customer",
        "device_token": fcmToken
      };
      var data = await apiClient.post("${EndPoints.saveFcmToken}", body: body);
      print("RESPONSEEEEE==$data");
      // sharedPreferenceHelper.saveUser(jsonEncode(data));
      // userModel = UserModel.fromJson(data);
      // isLoggedIn = true;
      // var isSave = await saveVisit();
      setSuccess();

      // return isSave;
    } on NetworkException catch (e) {
      onException(e);
      setSuccess();
      // return false;
    }
  }

  getLocations() {
    setLoading();
    try {
      if (locationList == null) {
        apiClient.get("${EndPoints.locationsList}").then((value) {
          locationList = LocationsModel.fromJson(value).data;

          District district = locationList[0].district[0];
          {
            List<Node> talukNodes = [];
            Taluk taluk = district.taluk[7];
            {
              List<Node> locationNodes = [];

              for (Location location in taluk.location) {
                locationNodes.add(
                  Node(
                      label: location.name,
                      key: "location-${location.id}",
                      expanded: false),
                );
              }
              talukNodes.add(
                Node(
                    children: locationNodes,
                    label: taluk.name,
                    key: "taluk-${taluk.id}",
                    expanded: false),
              );
            }
            nodes.add(Node(
                children: talukNodes,
                label: district.name,
                key: "dist${district.id}",
                icon: Icons.star));
          }
          setSuccess();
        });
      }
    } on NetworkException catch (e) {
      onException(e);
    }
  }*/





  /*getCompany() async {
    try {
      var data = await apiClient
          .get("${EndPoints.getCompany}?comp_name=Vazhuthakkadu Ward");
      companyList = Company.fromJson(data).data.toList();
      var companyData = await apiClient
          .get("${EndPoints.getCompanyLocation}?comp_id=${companyList[0].id}");
      await sharedPreferenceHelper.saveCompany(jsonEncode(companyData));
      companyPref = await sharedPreferenceHelper.getCompany();
      // company = Company.fromJson(data);
      setSuccess();
    } on NetworkException catch (e) {
      onException(e);
      setSuccess();
    }
    setSuccess();
    notifyListeners();
  }*/*/
}
