import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'base_view_model.dart';



class UserViewModel extends BaseViewModel {
  /*var hidePhone = false;
  var isLoggedIn = false;
  //Cmpany
  HomeViewModel homeViewModel;
  //Company
  List<CallLogData> callList = [];
  List<CallLogData> missedCallList = [];
  List<ChatData> chatList = [];
  List<VisitorData> visitorList = [];
  List<CategoryItemData> categoryItemList = [];
  List<CustomerOrderData> myOrders = [];
  List<ProductData> productData = [];
  List<PhotoOrderData> photoOrderItemList = [];
  List<OrderDetailsData> photoOrderDetailsList = [];
  List<OrderChatData> orderChatList = [];
  List<TextMessageData> textMessageList = [];
  List<ItemProduct> dupList = [];
  int increment = 10;
  ShopData shopData;
  UserModel userModel = UserModel(user: User());
  CompanyLocation company;
  CreateCallModel createCallModel;
  VisitData visitData;
  String modelAddress = '';
  // PhotoShopping
  double quantity = 0;
  List<String> images = [];
  List<double> qty = [];
  List<double> price = [];
  List<String> productName = [];
  List<Map<String, dynamic>> orderDetailsList = [];
  List<double> lineTotal = [];
  List<String> categoryTypes = [];
  String categoryHeading;
  double grandTotal = 0;
  AddressData addressModel;
  Future<bool> register() async {
    setLoading();
    try {
      var body = {
        "name": userModel.user.name,
        "phone_number": userModel.user.phoneNumber,
        "hide_status": hidePhone ? "1" : "0",
      };
      var data = await apiClient.post("${EndPoints.register}", body: body);
      sharedPreferenceHelper.saveUser(jsonEncode(data));
      userModel = UserModel.fromJson(data);
      isLoggedIn = true;
      // var isSave = await saveVisit();
      setSuccess();

      return true;
    } on NetworkException catch (e) {
      onException(e);
      return false;
    }
  }

  Future registerPhotoShop() async {
    setLoading();
    try {
      var body = {
        "name": userModel.user.name,
        "phone_number": userModel.user.phoneNumber,
        "hide_status": hidePhone ? "1" : "0",
        "address": userModel.user.customerAddress
      };
      var data = await apiClient.post("${EndPoints.register}", body: body);
      sharedPreferenceHelper.saveUser(jsonEncode(data));
      userModel = UserModel.fromJson(data);
      showToast('Registration Successful, Place Order', color: Colors.green);
      isLoggedIn = true;
      showToast('Registration Successful, Place Order', color: Colors.green);
      setSuccess();
    } on NetworkException catch (e) {
      onException(e);
      setSuccess();
    }
  }

  Future addAddress(String address) async {
    var userId = userModel.user.id;
    var body = {"customer_id": '$userId', "address": '$address'};
    try {
      setLoading();
      var addressData =
          await apiClient.post("${EndPoints.addAddress}", body: body);
      addressModel = AddressModel.fromJson(addressData).data;
      sharedPreferenceHelper.saveAddress(address);
      showToast('Registration Successful, Place Order', color: Colors.green);
      setSuccess();
      modelAddress = await sharedPreferenceHelper.getAddress();
    } on NetworkException catch (e) {
      setSuccess();
      onException(e);
    }
  }

  getVisitorList() {
    visitorList.clear();
    var userId = userModel.user.id;
    setLoading();
    print("get Visitors URL :${EndPoints.visitorList}/$userId");
    try {
      apiClient.get("${EndPoints.visitorList}/$userId").then((value) {
        visitorList = VisitorModel.fromJson(value).data.reversed.toList();
        setSuccess();
      });
    } on NetworkException catch (e) {
      visitorList = [];
      setSuccess();
      onException(e);
    }
  }

  getCallLogs() {
    callList.clear();
    missedCallList.clear();
    var userId = userModel.user.id;
    setLoading();
    print("get calls URL :${EndPoints.callLogs}?id=$userId");
    try {
      print("${EndPoints.callLogs}?id=$userId&call_type=customer");
      apiClient
          .get("${EndPoints.callLogs}?id=$userId&call_type=customer")
          .then((value) {
        callList = CallModel.fromJson(value).data.reversed.toList();

        setSuccess();

        for (int i = 0; i <= callList.length; i++) {
          if (callList.elementAt(i).callResponseStatus == "not attend" ||
              callList.elementAt(i).callResponseStatus == "rejected") {
            missedCallList.add(callList[i]);
            print("missedCallList.elementAt(i).userResponseStatus");
          }
        }
      });
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  Future<bool> rejectCall(var callLogId, var callStatus) async {
    setLoading();

    try {
      var body = {"call_status": callStatus, "call_flag": "0"};
      var data =
          await apiClient.put("${EndPoints.updateCall}$callLogId?", body: body);
      print("RESPONSEEEEE==$data");
      setSuccess();

      // return isSave;
    } on NetworkException catch (e) {
      onException(e);
      return false;
    }
  }

  Future<bool> saveVisit() async {
    setLoading();
    try {
      var body = {
        "customer_id": userModel.user.id.toString(),
        "shop_id": shopData.id.toString(),
        "visit_date": getDate(),
        "visit_time": getTime()
      };
      var data = await apiClient.post("${EndPoints.saveVisit}", body: body);
      visitData = VisitModel.fromJson(data).data;
      setSuccess();
      return true;
    } on NetworkException catch (e) {
      onException(e);
      setError();
      return false;
    }
  }

  getDate() {
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('dd-MM-yyyy');
    return formatter.format(now);
  }

  getTime() {
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('HH:mm:s');
    return formatter.format(now);
  }

  getProfile() async {
    userModel = await sharedPreferenceHelper.getUser();
    modelAddress = await sharedPreferenceHelper.getAddress();
    company = await sharedPreferenceHelper.getCompany();
    if (userModel == null) {
      isLoggedIn = false;
      userModel = UserModel(user: User());
    } else {
      isLoggedIn = true;
    }
    setSuccess();
    notifyListeners();
  }

  changeHide(bool value) {
    hidePhone = value;
    notifyListeners();
  }

  getChats(sellerId) async {
    chatList.clear();
    var userId = userModel.user.id;
    setLoading();
    print(
        "get chats URL :${EndPoints.getChats}customer_id=$userId&seller_id=$sellerId");
    try {
      await apiClient
          .get("${EndPoints.getChats}customer_id=$userId&seller_id=$sellerId")
          .then((value) {
        chatList = ChatModel.fromJson(value).data.toList();
        setSuccess();
      });
    } on NetworkException catch (e) {
      chatList = [];
      onException(e);
      setSuccess();
    }
  }

  getTextMessage() async {
    textMessageList.clear();
    var id = userModel.user.id;
    setLoading();
    print("get chats URL :${EndPoints.getTextMessage}$id");
    try {
      await apiClient.get("${EndPoints.getTextMessage}$id").then((value) {
        textMessageList =
            TextMessageModel.fromJson(value).data.reversed.toList();
        setSuccess();
      });
    } on NetworkException catch (e) {
      textMessageList = [];
      onException(e);
      setSuccess();
    }
  }

  Future sendFile(var sellerId, {var file, var flag}) async {
    setLoading();
    if (file == null) {
      showToast('No file chosen');
      return;
    }
    try {
      await apiClient.multipartRequest(EndPoints.upload,
          headers: {
            'Content-Type': 'multipart/form-data',
            'Charset': 'utf-8',
            // 'Content-Disposition': 'attachment; filename =$file'
          },
          body: {
            'customer_id': '${userModel.user.id}',
            'seller_id': '$sellerId',
            'call_type': 'customer',
            'picture_flag': '$flag'
          },
          filePath: file,
          field: 'file');
      setSuccess();
      getChats(sellerId);
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  Future sendMessage(var sellerId, {var flag, String message}) async {
    if (message == "" || message == null || message.length < 1) {
      showToast('Enter a valid message');
      return;
    }

    try {
      await apiClient.post(EndPoints.upload, body: {
        'customer_id': userModel.user.id,
        'seller_id': sellerId,
        'call_type': 'customer',
        'document_message': message,
        'picture_flag': '$flag'
      });
      getChats(sellerId);
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  // PHOTO SHOPPING
  getItemCategory(int sellerId) {
    setLoading();
    print(
        "get ItemCategory URL :${EndPoints.getItemCategory}?seller_id=$sellerId");
    categoryItemList.clear();
    categoryTypes.clear();
    try {
      apiClient
          .get("${EndPoints.getItemCategory}?seller_id=$sellerId")
          .then((value) {
        categoryItemList = CategoryItem.fromJson(value).data.toList();
        for (int i = 0; i < categoryItemList.length; i++) {
          if (categoryItemList[i].sellerItems.isEmpty) {
            categoryItemList.removeAt(i);
          }
        }
        categoryItemList.sort((a, b) => a.name.compareTo(b.name));
        for (int i = 0; i < categoryItemList.length; i++) {
          if (categoryItemList[i].sellerItems.isNotEmpty) {
            categoryTypes.add(categoryItemList[i].name);
          }
        }
        categoryTypes = categoryTypes.toSet().toList();
        setSuccess();
      });
    } on NetworkException catch (e) {
      categoryItemList = [];
      setSuccess();
      onException(e);
    }
  }

  createOrderDocument({sellerId, orderId, filepath, orderMess}) {
    var body = {
      'seller_id': '$sellerId',
      'customer_id': '${userModel.user.id}',
      'order_number': '$orderId',
      'order_message': '$orderMess',
      'picture_flag': '0'
    };
    try {
      apiClient.multipartRequest("${EndPoints.createOrder}",
          body: body, field: "image", filePath: filepath);
    } on NetworkException catch (e) {
      setSuccess();
      onException(e);
    }
  }

  createOrderDraft({sellerId, orderId, filepath, sellerItemId}) async {
    // List<String> filepath = [];

    // for (int i = 0; i < imagefiles.length; i++) {
    //   filepath.add(imagefiles[i].path);
    // }
    var body = {
      'order_number': '$orderId',
      'order_date_time': '${DateTime.now()}',
      'seller_id': '$sellerId',
      'customer_id': '${userModel.user.id}',
      'seller_item_id': '$sellerItemId',
      'order_status': 'Draft',
      'del_status': '0'
    };
    try {
      await apiClient.multipartRequest("${EndPoints.getOrders}",
          body: body, field: "s3_img_id", filePath: filepath);
      getCustomerOrders();
    } on NetworkException catch (e) {
      setSuccess();
      onException(e);
    }
  }

  confirmOrder({orderId}) {
    var body = {'order_number': '$orderId', 'order_status': 'Order'};
    try {
      apiClient.post("${EndPoints.confirmOrder}", body: body);
    } on NetworkException catch (e) {
      setSuccess();
      onException(e);
    }
  }

  getCustomerOrders() {
    var userId = userModel.user.id;
    setLoading();
    print("get Vieitors URL :${EndPoints.getOrders}?customer_id=$userId");
    try {
      apiClient.get("${EndPoints.getOrders}?customer_id=$userId").then((value) {
        myOrders = CustomerOrders.fromJson(value).data.reversed.toList();

        setSuccess();
      });
    } on NetworkException catch (e) {
      visitorList = [];
      setSuccess();
      onException(e);
    }
  }

  deleteOrders(int id) async {
    try {
      await apiClient.delete('${EndPoints.getOrders}/$id', headers: {
        "Content-Type": "application/json",
      });
      await getCustomerOrders();
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  getProductDetails({int sellerId, int catItemId}) async {
    try {
      await apiClient
          .get(
              '${EndPoints.getItemProduct}?seller_id=$sellerId&seller_item_id=$catItemId')
          .then((value) {
        productData = ProductDetails.fromJson(value).data.toList();
      });
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  Future sendPhotoshopOrder({sellerId, orderId, orderDetList}) async {
    var body = {
      'order_number': '$orderId',
      'order_date_time': '${DateTime.now()}',
      'seller_id': '$sellerId',
      'customer_id': '${userModel.user.id}',
      // 'seller_item_id': '$sellerItemId',
      'order_status': 'Draft',
      'del_status': '0',
      "orderDetails": orderDetList
    };
    try {
      await apiClient.post('${EndPoints.sendPhotoshopOrder}', body: body);
      showToast("Your Order is Successfully placed, Refresh to view your Order",
          color: Colors.green);
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  Future getPhotoOrders() async {
    var userId = userModel.user.id;
    photoOrderItemList = [];
    setLoading();
    try {
      await apiClient
          .get("${EndPoints.getPhotoOrdersList}$userId")
          .then((value) {
        photoOrderItemList = PhotoOrderModel.fromJson(value).data ?? [];
        setSuccess();
      });
    } on NetworkException catch (e) {
      onException(e);
      setError();
    }
  }

  Future getPhotoOrderDetails(int orderId) async {
    // var userId = userModel.user.id;
    photoOrderDetailsList = [];
    setLoading();
    try {
      await apiClient
          .get("${EndPoints.getPhotoOrderDetails}$orderId")
          .then((value) {
        photoOrderDetailsList = PhotoOrderDetails.fromJson(value).data ?? [];
        setSuccess();
      });
    } on NetworkException catch (e) {
      onException(e);
      setError();
    }
  }

  Future getOrderChats(orderId) async {
    orderChatList = [];
    setLoading();
    print("get chats URL :${EndPoints.orderChat}?seller_order_id=$orderId");
    try {
      await apiClient
          .get("${EndPoints.orderChat}?seller_order_id=$orderId")
          .then((value) {
        orderChatList = OrderChat.fromJson(value).data.toList();
        setSuccess();
      });
    } on NetworkException catch (e) {
      orderChatList = [];
      onException(e);
      setSuccess();
    }
  }

  Future sendOrderChatFile(var orderId, {var file, var flag}) async {
    if (file == null) {
      showToast('No file chosen');
      return;
    }
    setLoading();
    try {
      await apiClient.multipartRequest(EndPoints.orderChat,
          headers: {
            'Content-Type': 'multipart/form-data',
            'Charset': 'utf-8',
            // 'Content-Disposition': 'attachment; filename =$file'
          },
          body: {
            'seller_order_id': '$orderId',
            'type': 'customer',
            'picture_flag': '$flag'
          },
          filePath: file,
          field: 'file');
      setSuccess();
      getOrderChats(orderId);
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  sendPush(String deviceToken, String shopName) async {
    String firebaseKey =
        "key=AAAA5qP61F4:APA91bF20da4kANdL-t3tL73gNN8EP9qLjyEvEKg-OrdFAkV2-vzPoaRGJo0fqr6s7EkwItOz1kiM9qcHZX62-4kOi3Umt-c7R9-shzUOCGBsH3rfnwv9K9Q-fgiG5VBvIZepwb5dsyI";
    var nameCustomer = userModel.user.name;
    print("*********Sending Notification**********");
    print("$nameCustomer : $deviceToken");
    setLoading();
    try {
      var data =
          await apiClient.post("https://fcm.googleapis.com/fcm/send", headers: {
        "Content-Type": "application/json",
        "authorization": firebaseKey
      }, body: {
        "to": deviceToken,
        "notification": {
          "body": "$nameCustomer has sent you an order.",
          "OrganizationId": "2",
          "content_available": true,
          "priority": "high",
          "subtitle": "Elementary School",
          "title": "Hello $shopName",
          "sound": "cellphonenotif.mp3",
          "android_channel_id": "high_importance_channel"
        },
        "data": {
          "body": "New Announcement assigned",
          "organization": "Elementary school"
        }
      });
    } on NetworkException catch (e) {
      onException(e);
      setError();
      return false;
    }
  }

  Future sendMessageOrder(var orderId, {var flag, String message}) async {
    if (message == "" || message == null || message.length < 1) {
      showToast('Enter a valid message');
      return;
    }

    try {
      await apiClient.post(EndPoints.orderChat, body: {
        'seller_order_id': '$orderId',
        'picture_flag': '$flag',
        'type': 'customer',
        'document_message': message,
      });
      getOrderChats(orderId);
    } on NetworkException catch (e) {
      onException(e);
    }
  }

  removeDialog(int index) {
    if (dupList.length >= 1) {
      dupList.removeAt(index);
      notifyListeners();
    }
  }

  nextDigit() {
    if (increment <= 99) {
      increment++;
    } else {
      increment = 10;
      print(increment);
    }
    // notifyListeners();
    return increment;
  }

  setHeading(String newValue) {
    categoryHeading = newValue;
    notifyListeners();
  }*/
}
