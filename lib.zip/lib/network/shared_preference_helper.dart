// @dart=2.9
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../model/user_model.dart';


class SharedPreferenceHelper {
  FlutterSecureStorage _sharedPreference = FlutterSecureStorage();

  initSharedPreference() async {
    _sharedPreference = FlutterSecureStorage();
  }

  saveUser(String data) {
    _sharedPreference.write(key: "profile", value: data);
  }

  saveAddress(String address) {
    _sharedPreference.write(key: "address", value: address);
  }

  saveCompany(String companyData) {
    _sharedPreference.write(key: "location", value: companyData);
  }

  removeAll() async {
    await _sharedPreference.deleteAll();
  }

  Future<UserModel> getUser() async {
    var data = await _sharedPreference.read(key: "profile");
    if (data != null) {
      return UserModel.fromJson(jsonDecode(data));
    } else {
      return null;
    }
  }

  Future<String> getAddress() async {
    var data = await _sharedPreference.read(key: "address");
    if (data != null) {
      return data;
    } else {
      return null;
    }
  }

/* Future<CompanyLocation> getCompany() async {
    var data = await _sharedPreference.read(key: "location");
    if (data != null) {
      return CompanyLocation.fromJson(jsonDecode(data));
    } else {
      return null;
    }
  }
}*/
}
