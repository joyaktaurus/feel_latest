class EndPoints {
  static final String baseUrl = "https://api-test.videoshopping.in/api/";

  //get districts
  // comapny
  static final String getCompany = "${baseUrl}company";
  static final String getCompanyLocation = "${baseUrl}company-location?";

  //company
  static final String getDistricts = "${baseUrl}district";
  static final String getStoresByTaluk = "${baseUrl}stores";
  static final String findNearByShops = "${baseUrl}nearest-location";
  static final String locationsList = "${baseUrl}locations";
  static final String login = "${baseUrl}login";
  static final String register = "${baseUrl}customer";
  static final String saveVisit = "${baseUrl}save-visit";
  static final String createCall = "${baseUrl}call-log";
  static final String saveFcmToken = "${baseUrl}fcm-token";
  static final String callLogs = "${baseUrl}user-calls";
  static final String visitorList = "${baseUrl}list-visit-customer";
  static final String updateCall = "${baseUrl}call-log/";
  static final String getChats = "${baseUrl}call-document-calllog?";
  static final String upload = "${baseUrl}call-document";
  static final String getItemCategory = "${baseUrl}seller-item";
  static final String createOrder = "${baseUrl}order-document";
  static final String getOrders = "${baseUrl}order";
  static final String confirmOrder = "${baseUrl}confirm-order";
  static final String getItemProduct = "${baseUrl}seller-item-product-list";
  static final String sendPhotoshopOrder = "${baseUrl}seller-order";
  static final String getPhotoOrdersList =
      "${baseUrl}seller-order-list?customer_id=";
  static final String getPhotoOrderDetails =
      "${baseUrl}seller-order-details?seller_order_id=";
  static final String orderChat = "${baseUrl}order-chat";
  static final String getTextMessage = "${baseUrl}list-chats?customer_id=";
  static final String addAddress = "${baseUrl}add-address";
}
