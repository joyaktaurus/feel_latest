// @dart=2.9
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'Screens/splash_screen.dart';
import 'view_models/home_view_model.dart';
import 'view_models/user_view_model.dart';

void main() async {
  // await SystemAlertWindow.requestPermissions(prefMode: prefMode);
  runApp(MyApp());
  await Permission.camera.request();
  await Permission.microphone.request();
  WidgetsFlutterBinding.ensureInitialized();

}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HomeViewModel()),
        ChangeNotifierProvider(create: (_) => UserViewModel()),
      ],
      child: MaterialApp(
          navigatorKey: navigatorKey,
          debugShowCheckedModeBanner: true,
          title: 'Feel At Home',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            visualDensity: VisualDensity.adaptivePlatformDensity,
          ),
          home: ShowSplash()),
    );
  }
  final GlobalKey<NavigatorState> navigatorKey = new GlobalKey<NavigatorState>();
  bool isFromFcm = false;
}